#!/bin/bash
echo "this script is very old, use the one at github.com/parrotsec/anonsurf instead"
