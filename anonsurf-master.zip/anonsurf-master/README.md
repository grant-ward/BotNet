anonsurf
========
this repo is no more used,

check github.com/parrotsec/anonsurf instead

========

ParrotSec AnonSurf core module


this script is preinstalled on Parrot Security OS (www.parrotsec.org)

and its aim is to provide a strong system-wide anonymization module for our operating system
