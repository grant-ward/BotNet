<!DOCTYPE html>
<html lang="pt-BR">
<head>
	<meta charset="utf-8">
	<title>Comunicado Hydra</title>
	<link rel="stylesheet" type="text/css" href="css/estilo.css">
</head>
<body>

	<header>
		<img src="images/logo.png" alt="Comunicado Hydra" title="Comunicado Hydra">
		<h1>Comunicado</h1>
	</header>

	<article>
		<p>Saudações meus amigos hydrianos, hoje venho comunicar não com tristeza mas com muita alegria nossa interrupção no projeto hydra,
		Mas porque com muita alegria?</p>
		<p>Porque estamos finalizando um projeto que cumpriu o planejado, ajudou muitas pessoas e em momento algum teve suas convicções corrompidas. Aqui vocês não foram simples membros, pra gente fomos todos uma família.</p>
		<p>A interrupção do projeto se deve ao fato da staff estar sem tempo para se dedicar, esse não é um completo "fim", a ideia não está morta, apenas foi adiada para um futuro próximo ou não.</p>


		<h2>HISTÓRIA</h2>

		<p>Para contar essa história precisamos voltar um pouco no tempo ate a época em que o projeto MI-6 era vivo, Hydra nasceu a partir de alguns usuários da staff do MI-6, MI-6 tinha ideias legais, não praticava nenhum ato ilícito mas contava com uma staff ainda imatura de fácil manipulação e imaturidade para lidar com alguns problemas, por conta disto se ocorreu varias discórdias internas que fizeram com que seu fim fosse inevitável. </p>

		<p>Hydra por sua vez teve todo um cuidado e planejamento para que isso não voltasse a acontecer, dessa vez já com a staff mais madura e preparada, 
		teve inicio em 9 de Junho de 2016, mesmo não tendo recebido ajuda direta de nenhum meio de comunicação, nesses quase 7 meses de atividade se tornou um dos maiores sites brasileiros da Deep Web, referencia em honestidade e humildade não teve problemas internos ou externos.
		</p>

		<h2>PROJETOS ATIVOS</h2>

		<p>Ainda vamos manter nossos projetos privados na ativa, mas o fórum e irc será parado, temos algumas ferramentas quase finalizadas e essas serão disponibilizadas ao publico pelo github, dia 1 de Janeiro de 2017 tanto o server do fórum quanto do irc serão desligados, mas vamos ligar o server de novo para anunciar novidades sobre as ferramentas e novos projetos.</p>

		<h1>Hail Hydra!</h1>
	</article>

</body>
</html>